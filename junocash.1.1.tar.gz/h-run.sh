#!/usr/bin/env bash
cd "$(dirname "$0")"

conf_dir="$1"

MINER_NAME="junocash"
LOG_DIR="/var/log/miner/${MINER_NAME}"
mkdir -p "$LOG_DIR"
LOG_FILE="${LOG_DIR}/${MINER_NAME}.log"

chmod +x ./xmrig

./xmrig -c "$conf_dir/config.json" 2>&1 | tee "$LOG_FILE"
