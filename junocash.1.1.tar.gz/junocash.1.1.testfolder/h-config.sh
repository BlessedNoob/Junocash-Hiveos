#!/usr/bin/env bash

conf_dir="$1"

mkdir -p "$conf_dir"

cat > "$conf_dir/config.json" << EOF
{
  "autosave": true,
  "cpu": {
    "enabled": true
  },
  "pools": [
    {
      "url": "$CUSTOM_URL",
      "user": "$CUSTOM_TEMPLATE",
      "pass": "x"
    }
  ]
}
EOF
