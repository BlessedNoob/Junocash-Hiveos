#!/usr/bin/env bash
conf_dir="$1"

cat > "$conf_dir/config.json" << CFG
{
  "pools": [
    {
      "url": "$CUSTOM_URL",
      "user": "$CUSTOM_TEMPLATE",
      "pass": "$CUSTOM_PASS",
      "rig-id": "$WOKER_NAME",
      }
  ]
}
CFG
