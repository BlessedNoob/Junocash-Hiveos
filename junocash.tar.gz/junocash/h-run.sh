#!/usr/bin/env bash

# Prevent double-running
if [[ $(ps aux | grep '[x]mrig' | wc -l) -gt 0 ]]; then
    echo "Junocash miner is already running"
    exit 1
fi

# HugePages tuning (same behavior as official XMRig integration)
function HugePagesTune() {
    if [[ -n $CUSTOM_HUGEPAGES ]]; then
        echo "Applying HugePages override: $CUSTOM_HUGEPAGES"
        hugepages "$CUSTOM_HUGEPAGES"
    else
        echo "Auto HugePages tuning for RandomX..."
        sysctl -w vm.nr_hugepages=0 > /dev/null
        hugepages -rx
    fi
}

HugePagesTune

#############################################
# Miner execution
#############################################

cd "$(dirname "$0")"
conf_dir="$1"

# Load miner metadata
. ./h-manifest.conf

LOG_DIR="/var/log/miner/${MINER_NAME}"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/${MINER_NAME}.log"

# Add miner libs to loader path
export LD_LIBRARY_PATH="$(pwd):${LD_LIBRARY_PATH}"

# Verify config.json exists
if [[ ! -f "$conf_dir/config.json" ]]; then
    echo "ERROR: config.json missing → $conf_dir/config.json"
    exit 1
fi

# XMRig API port from HiveOS
API_PORT=${MINER_API_PORT:-40100}

# Run XMRig with API enabled (REQUIRED for h-stats.sh)
exec ./xmrig \
    --config "$conf_dir/config.json" \
    --http-enabled \
    --http-host 127.0.0.1 \
    --http-port $API_PORT \
    2>&1 | tee -a "$LOG_FILE"
