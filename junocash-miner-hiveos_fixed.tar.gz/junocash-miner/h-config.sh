#!/usr/bin/env bash
# TNN-style config injection for XMrig

cd "$(dirname "$0")"
CONF="config.json"

# Replace pool URL
if [ -n "${CUSTOM_URL}" ]; then
    sed -i "s|\"url\": \".*\"|\"url\": \"${CUSTOM_URL}\"|" "$CONF"
fi

# Replace wallet / user
if [ -n "${CUSTOM_USER}" ]; then
    sed -i "s|\"user\": \".*\"|\"user\": \"${CUSTOM_USER}\"|" "$CONF"
fi

# Replace password
if [ -n "${CUSTOM_PASS}" ]; then
    sed -i "s|\"pass\": \".*\"|\"pass\": \"${CUSTOM_PASS}\"|" "$CONF"
fi

# Replace rig-id
if [ -n "${WORKER_NAME}" ]; then
    sed -i "s|\"rig-id\": null|\"rig-id\": \"${WORKER_NAME}\"|" "$CONF"
    sed -i "s|\"rig-id\": \".*\"|\"rig-id\": \"${WORKER_NAME}\"|" "$CONF"
fi

exit 0
