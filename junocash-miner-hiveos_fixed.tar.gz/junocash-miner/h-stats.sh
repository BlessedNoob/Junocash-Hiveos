#!/usr/bin/env bash
# Minimal stats script (compatible with HiveOS)
# You can enhance later to parse xmrig.log

echo "khs=0"
