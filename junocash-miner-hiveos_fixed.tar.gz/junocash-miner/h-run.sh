#!/usr/bin/env bash
# TNN-style run script for HiveOS

cd "$(dirname "$0")"

# Inject config
./h-config.sh || exit 1

echo "Starting Junocash XMrig miner..."
exec ./start.sh
