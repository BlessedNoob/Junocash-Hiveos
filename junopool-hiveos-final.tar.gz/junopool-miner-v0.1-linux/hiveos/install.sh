#!/bin/bash
echo "Installing JunoPool Miner (xmrig)..."
cd "$(dirname "$0")/.."
chmod +x miner/xmrig || true
chmod +x miner/start.sh || true
echo "Installation complete."
exit 0
