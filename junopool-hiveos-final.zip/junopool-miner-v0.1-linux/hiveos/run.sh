#!/bin/bash

# HiveOS custom miner launcher for JunoPool xmrig
# Uses HiveOS environment variables:
#   CUSTOM_URL  - pool URL
#   CUSTOM_USER - wallet address
#   CUSTOM_PASS - password / worker string
#   WORKER_NAME - rig name

cd "$(dirname "$0")/../miner"

if [ ! -f config.json ]; then
    echo "config.json not found in miner directory!"
    exit 1
fi

# Update pool settings in config.json using HiveOS variables
if [ -n "${CUSTOM_URL}" ]; then
    sed -i "s|"url": ".*"|"url": "${CUSTOM_URL}"|" config.json
fi

if [ -n "${CUSTOM_USER}" ]; then
    sed -i "s|"user": ".*"|"user": "${CUSTOM_USER}"|" config.json
fi

if [ -n "${CUSTOM_PASS}" ]; then
    sed -i "s|"pass": ".*"|"pass": "${CUSTOM_PASS}"|" config.json
fi

if [ -n "${WORKER_NAME}" ]; then
    # handle null or existing string
    sed -i "s|"rig-id": null|"rig-id": "${WORKER_NAME}"|" config.json
    sed -i "s|"rig-id": ".*"|"rig-id": "${WORKER_NAME}"|" config.json
fi

chmod +x xmrig

echo "Starting xmrig for JunoPool..."
exec ./xmrig --config=config.json
