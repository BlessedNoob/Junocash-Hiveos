JunoPool Miner - HiveOS Custom Miner Package
===========================================

Structure:
- hiveos/install.sh         : called once on miner install
- hiveos/run.sh             : called every miner start by HiveOS
- hiveos/config_example.json: base xmrig config used as example
- miner/xmrig               : xmrig-based JunoPool miner binary
- miner/config.json         : active xmrig config (modified by run.sh)
- miner/start.sh            : original start script (not used by HiveOS)

Usage in HiveOS:
- Upload this zip as a Custom Miner.
- In the Flight Sheet for this miner, set:
    URL   = your JunoPool stratum URL (e.g. stratum+tcp://pool.juno.ad:3333)
    USER  = your Juno wallet address
    PASS  = x or worker name, etc.

run.sh will patch config.json with those values and start xmrig.
